<?php
require_once 'DB.php';

$db = new DB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($db->authenticateUser($email, $password)) {
        // Retrieve the profile picture path from the database
        $profilePic = $db->getUserProfilePic($email); // Assuming you have a method in your DB class to fetch the profile picture path
        
        // Set the profile picture path as a session variable
        session_start();
        $_SESSION['profilepic'] = $profilePic;

        header("Location: ../pages/home.php");
        exit;
    } else {
        echo "<script>alert('Invalid email or password');
        var img = document.createElement('img');
        img.src = '/partials/img.webp'; 
        var alertContent = document.querySelector('.swal-text');
        alertContent.insertBefore(img, alertContent.firstChild);
        </script>";
        echo "<script>history.back();</script>";
    }
}
?>
