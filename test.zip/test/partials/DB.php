<?php
class DB
{
    private $hostname = 'localhost';
    private $username = 'root';
    private $password = '';
    private $db = 'test';
    protected ?PDO $conn;

    public function __construct()
    {
        try {
            $this->conn = new PDO("mysql:host=$this->hostname;dbname=$this->db", $this->username, $this->password);
            $this->setErrorAttribute();
        } catch (PDOException $e) {
            throw new Exception("Unable to connect Database");
        }
    }

    public function getConnection(): ?PDO
    {
        return $this->conn;
    }

    public function setErrorAttribute(): void
    {
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function createTable($tableName, $columns): void
    {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS $tableName ($columns)";
            $this->conn->exec($sql);
            echo "Table '$tableName' created successfully.<br>";
        } catch (PDOException $e) {
            echo "Error creating table: " . $e->getMessage()."<br>";
        }
    }
    public function addColumn($tableName, $columnName, $columnDefinition): void
{
    try {
        $sql = "ALTER TABLE $tableName ADD COLUMN $columnName $columnDefinition";
        $this->conn->exec($sql);
        echo "Column '$columnName' added successfully to table '$tableName'.<br>";
    } catch (PDOException $e) {
        echo "Error adding column: " . $e->getMessage()."<br>";
    }
}

    public function deleteTable($tableName) {
        try {
            $sql = "DROP TABLE IF EXISTS $tableName";
            $this->conn->exec($sql);
            echo "Table '$tableName' deleted successfully.<br>";
        } catch (PDOException $e) {
            echo "Error deleting table: " . $e->getMessage() . "<br>";
        }
    }
    public function getUserProfilePic($email)
    {
        try {
            $sql = "SELECT profilepic FROM users WHERE email = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([$email]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
            if ($result && isset($result['profilepic'])) {
                return $result['profilepic'];
            } else {
                return null; // Return null if no profile picture found
            }
        } catch (PDOException $e) {
            echo "Error retrieving profile picture: " . $e->getMessage();
            return null; // Return null on error
        }
    }
    
    public function insertRecords($tableName, $columns, $values, $params): void
    {
        $stmt = $this->conn->prepare("INSERT INTO `$tableName` ($columns) VALUES ($values)");
        $stmt->execute($params);
    }

    public function updateRecords($tableName, $set, $where, $params): void
    {
        $stmt = $this->conn->prepare("UPDATE `$tableName` SET $set WHERE $where");
        $stmt->execute($params);
    }
    public function selectRecordsWithOrder($tableName, $columns, $orderBy): array
    {
        $sql = "SELECT $columns FROM `$tableName` ORDER BY $orderBy";
        $stmt = $this->conn->query($sql);
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $records;
    }

    public function authenticateUser($email, $password): bool
    {
        $stmt = $this->conn->prepare("SELECT * FROM `users` WHERE `email` = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && $user['password'] === $password) {
            return true;
        }

        return false;
    }
}
