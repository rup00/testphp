<?php

require_once 'DB.php';

$db = new DB();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    $table = 'users';
    $columns = 'name, email, password, profilepic'; 
    $values = '?, ?, ?, ?';
    $params = [$_POST['name'], $_POST['email'], $_POST['password'], '']; 

    if (isset($_FILES['profilepic']) && $_FILES['profilepic']['error'] === UPLOAD_ERR_OK) {
        $tempFile = $_FILES['profilepic']['tmp_name'];
        $fileName = $_FILES['profilepic']['name'];
        $temp_path = 'C:\laragon\www\test\pages';
        $filePath = $temp_path .'/partials/profile_pictures/' . $fileName; 
        $dbpath = 'partials/profile_pictures/' . $fileName;
        move_uploaded_file($tempFile, $filePath);
        
        $params[3] = $dbpath; 
    }

    try {
        $db->insertRecords($table, $columns, $values, $params);
        header("Location: ../pages/login.html");
    } catch (PDOException | Exception $e) {
        echo "Signup failed: " . $e->getMessage();
    }
}
?>