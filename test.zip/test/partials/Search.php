<?php

require_once 'DB.php';

$db = new DB();

$search_term= $_REQUEST["search_term"];
$hint = "";

if ($search_term !== "") {
    $search_term = strtolower($search_term);

    $stmt = $db->getConnection()->prepare("SELECT name FROM Names WHERE LOWER(name) LIKE ?");
    $stmt->execute(["%" . $search_term . "%"]);

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($result as $row) {
        $name = $row['name'];

        if ($hint === "") {
            $hint = "$name";
        } else {
            $hint .= ", $name";
        }
    }
}


echo $hint === "" ? "<img src='/partials/zhymg.jpg' alt='No search results' />" : $hint;
