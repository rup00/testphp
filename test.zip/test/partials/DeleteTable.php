<?php
require_once 'DB.php';

$db = new DB();


$db->deleteTable('polution');
