<?php
// Interface definition
interface Animal {
  public function makeSound();
}

// Class definitions
class Cat implements Animal {
  public function makeSound() {
    echo "Meow";
  }
}

class Dog implements Animal {
  public function makeSound() {
    echo "Bark";
  }
}

class Mouse implements Animal {
  public function makeSound() {
    echo "Squeak";
  }
}

// Create a list of animals
$cat = new Cat();
$dog = new Dog();
$mouse = new Mouse();
$animals = array($cat, $dog, $mouse);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['animal'])) {
    $selectedAnimal = $_POST['animal'];
    foreach ($animals as $animal) {
      if (get_class($animal) === $selectedAnimal) {
        $animal->makeSound();
        break;
      }
    }
  }
}
?>
