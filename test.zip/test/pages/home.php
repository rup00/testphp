<?php
session_start();
if (isset($_SESSION['profilepic']) && !empty($_SESSION['profilepic'])) {
  $profilePic = $_SESSION['profilepic'];
  echo '<img src="' . $profilePic . '" alt="Profile Picture" class="mb-4 h-2/3 rounded-full">';
} else {
  echo '<img src="images.jfif" alt="Default Profile Picture" class="mb-4">';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Home</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.16/dist/tailwind.min.css" rel="stylesheet">
  <style>

    .search-input {
      position: relative;
    }

    .search-suggestions {
      position: absolute;
      top: 100%;
      left: 57px;
      right: 89px;
      z-index: 10;
      background-color: white;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      max-height: 200px;
      overflow-y: auto;
      padding: 4px;
    }

    .search-suggestion {
      padding: 4px;
      cursor: pointer;
    }

    .search-suggestion:hover {
      background-color: #f5f5f5;
    }
  </style>
</head>
<body>
  <nav class="flex justify-between items-center bg-blue-500 p-4">
    <div>
      <a href="#" class="text-white font-semibold">Logo</a>
    </div>
    <div>
      <ul class="flex">
        <li class="mr-4">
          <a href="http://test.test/pages/home.php" class="text-white">Home</a>
        </li>
        <li class="relative">
          <a href="http://test.test/pages/dropdown.php" class="text-white">Dropdown</a>
        </li>
      </ul>
    </div>
  </nav>

  <h1 class="text-2xl font-semibold mb-4">Welcome</h1>
  <h4 class="mb-4">You Can Search Here</h4>

  <form action="" class="search-input">
    <label for="search">Search:</label>
    <input
      type="text"
      id="search"
      name="search"
      onkeyup="showHint(this.value)"
      class="border border-gray-300 px-3 py-2 rounded-lg focus:outline-none focus:border-blue-500"
    />
    <div id="txtHint" class="search-suggestions"></div>
    <button type="button" onclick="logout()" class="bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded mt-2">Logout</button>
  </form>

  <script>
    document.getElementById("search").addEventListener("keyup", function () {
      showHint(this.value);
    });

    function showHint(str) {
      if (str.length == 0) {
        document.getElementById("txtHint").innerHTML = "";
        return;
      } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
          if (this.readyState == 4 && this.status == 200) {
            document.getElementById("txtHint").innerHTML = this.responseText;
          }
        };
        xmlhttp.open("GET", "../partials/Search.php?search_term=" + str, true);
        xmlhttp.send();
      }
    }

    function logout() {
      alert('Logged out');
      window.location.href = "../pages/Login.html";
    }
  </script>
</body>
</html>
