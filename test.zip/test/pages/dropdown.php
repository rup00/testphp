<?php
include 'animals.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Animal Sounds</title>
  <style>
    .dropdown {
      position: relative;
      display: inline-block;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      padding: 12px 16px;
      z-index: 1;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    .sound-output {
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <h1>Animal Sounds</h1>
  
  <div class="dropdown">
    <button class="dropbtn">Select an Animal</button>
    <div class="dropdown-content">
      <?php foreach ($animals as $animal): ?>
        <form method="POST">
          <button type="submit" name="animal" value="<?php echo get_class($animal); ?>"><?php echo get_class($animal); ?></button>
        </form>
      <?php endforeach; ?>
    </div>
  </div>
  
  <div class="sound-output">
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($selectedAnimal)) {
      echo "<p>Selected animal sound: ";
      foreach ($animals as $animal) {
        if (get_class($animal) === $selectedAnimal) {
          $animal->makeSound();
          break;
        }
      }
      echo "</p>";
    }
    ?>
  </div>
</body>
</html>
