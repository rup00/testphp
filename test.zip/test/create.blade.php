@extends('layouts.app')

@section('content')
<div class=" py-4 px-4 xl:px-24 pt-6">
    <form action="{{route('brand.store.campaign')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <!-- Step 1 -->
        <div id="step-1" class="pb-10 bg-white mx-auto max-w-4xl py-4 px-4 lg:px-12 shadow-xl mb-24 rounded-3xl">
            <h2 class="text-center text-2xl font-semibold my-5">Campaign Info</h2>

            <div class="">
                <div class="-mx-3 md:flex mb-2">
                    <div class="md:w-1/2 px-3 mb-3 md:mb-0">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Campaign Name
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-1" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-1" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Displayed for influencers to see
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <input class="text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4 mt-2" id="company" type="text" placeholder="Campaign Name" name="name" value="{{old('name')}}">
                        @error('name')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="md:w-1/2 px-3">
                        <div class="flex items-center">
                            <label class="tracking-wide text-black text-xs flex" for="title">
                                Campaign Type
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-2" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-2" role="tooltip" class="absolute w-52 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Paid- Budget allocated to campaign for influencers
                                <br>
                                <p>
                                    <strong>
                                        Gift-
                                    </strong> Product/Service offered complimentary to influencers as part of the
                                    requirement to create content
                                </p>
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <select name="campaign_type" id="campaign_type" onchange="handlecampaignbudget()" class="text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                            <option value="paid">Paid</option>
                            <option value="paidgift">Paid + Gift</option>
                            <option value="gift">Gift</option>
                        </select>
                        @error('campaign_type')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                </div>
                <div class="-mx-3 md:flex mb-2">
                    <div class="md:w-1/2 px-3 mb-2 md:mb-0">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs flex" for="company">
                                Campaign Objective
                            </label>
                            <x-grey-label-text>
                                &nbsp;(Select all that apply)
                            </x-grey-label-text>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-3" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-3" role="tooltip" class="absolute w-52 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Let influencers know the main objective of running the campaign
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <select id="mySelect" multiple name="campaign_objective[]" class="js-example-placeholder-single select2 text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                            <option disable></option>
                            @foreach ($campaign_objective as $obj => $id)
                            @if(old('campaign_objective'))
                            <option value="{{$id->id}}" {{ in_array($id->id, old('campaign_objective')) ? 'selected' : '' }}>
                                {{$id->name}}
                            </option>
                            @else
                            <option value="{{$id->id}}">
                                {{$id->name}}
                            </option>
                            @endif
                            @endforeach
                        </select>
                        @error('campaign_objective')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="md:w-1/2 px-3 mb-2 md:mb-0">
                        <div class="flex">
                            <label class=" tracking-wide text-xs mb-2 flex" for="company">
                                Total Campaign Budget
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                        </div>
                        <input class=" text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4  mt-2" id="campaign_budget" pattern="[0-9]+" type="number" name="total_budget" placeholder="Total Campaign Budget" value="{{old('total_budget')}}" oninput="this.value = this.value.replace(/[^0-9]/g,''); calculateBudget(this)">
                        @error('total_budget')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                        <div class="budget-result"></div>

                    </div>
                </div>
                <div class="-mx-3 md:flex mb-6">
                    <div class="md:w-1/2 px-3 mb-6 md:mb-0">
                        <div class="flex items-center mb-3">
                            <label class="  tracking-wide text-black text-xs flex" for="summernote_summary">
                                Campaign Summary
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-4" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-4" role="tooltip" class="absolute w-72 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Short description of what this campaign is about. <br> <br>
                                <strong class="italic">
                                    Example
                                </strong> (<i>The goal of this campaign is to promote our business through sponsored
                                    posts featuring our products. Through this collaboration, we hope to increase
                                    brand
                                    awareness and drive sales among a highly engaged and targeted audience.</i>)
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <textarea name="summary" id="summernote_summary" class="summernote_summary">{{old('summary')}}</textarea>
                        <p>Character length <span id="summeryCharCount">0</span></p>
                        <strong id="summeryErrorMessage" style="color: red; display: none;">Character limit exceeded!</strong>
                        <strong style="color: red; font-size: 12px; margin-top: -15px;" id="summaryError"></strong>
                        @error('summary')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="md:w-1/2 px-3">
                        <div class="flex items-center mb-2">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Add Campaign Picture
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-5" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-5" role="tooltip" class="absolute w-52 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Image that the influencers will see when looking for your campaign
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <div class="w-full relative flex flex-col p-4  text-gray-400 border border-gray-200 border-dashed rounded rounded mt-2">
                            <div class="relative flex flex-col text-gray-400  cursor-pointer">
                                <input accept="*" type="file" name="images" class="absolute campaignImg inset-0 z-50 w-full h-full p-0 m-0 outline-none opacity-0 cursor-pointer" title="" />

                                <div class="flex flex-col items-center justify-center py-10 text-center">
                                    <svg class="w-6 h-6 mr-1 text-current-50" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                    <p class="m-0 text-dark">Drag & Drop Your Image Here.</p>
                                    <p class="m-0">OR</p>
                                    <a class="underline-offset-8 text-blue-500" style="text-decoration:underline;" href="#">Browse</a>
                                </div>
                            </div>

                            <span id="campaignImg">
                                <img alt="Placeholder" class="block h-20 rounded-lg hidden"
                                        src="">
                            </span>
                            @error('images')
                            <span class="text-red-600">{{ $message }}</span>
                            @enderror
                        </div>


                        <div class="mt-1 text-sm text-gray-500 dark:text-gray-300" id="user_avatar_help">Accepted
                            Image
                            Types:JPG and PNG Only
                        </div>
                    </div>
                </div>

                <div class="-mx-3 md:flex mb-6">
                    <div class="md:w-1/2 px-3 mb-6 md:mb-0">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Campaign Start
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-6" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-6" role="tooltip" class="absolute w-52 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Date Influencers are able to start posting
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <input class="text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4 mb-3 mt-2" id="company" type="date" name="campaign_start" value="{{now()->format('Y-m-d')}}">
                        @error('campaign_start')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="md:w-1/2 px-3 mb-6 md:mb-0">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Campaign Deadline
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-7" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-7" role="tooltip" class="absolute w-52 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Date Influencers should have finished posting
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <input class="text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4 mb-3 mt-2" id="company" type="date" name="campaign_deadline" value="{{old('campaign_deadline')}}">
                        @error('campaign_deadline')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class=" flex w-full px-3 justify-center iteams-center">
                    <button id="fresh" type="button" class="text-white self-center w-96 bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" onclick="showStep(2)">Next
                    </button>
                </div>
            </div>

        </div>

        <!-- Step 2 -->
        <div id="step-2" class="hidden pb-10 bg-white mx-auto max-w-4xl py-4 px-4 lg:px-12 shadow-xl mb-24 rounded-3xl">
            <h2 class="text-center text-2xl font-semibold my-5">Content Guideline</h2>

            <div class="">
                <div class="-mx-3 md:flex mb-2">
                    <div class="md:w-1/2 px-3">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Trackable Hashtag
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-8" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-8" role="tooltip" class="absolute w-52 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Hashtag automatically generated by Eros to track all posts and content for your
                                campaign. (<i>This cannot be removed</i>)
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <div class="flex">
                            <span class="inline-flex text-xs bg-white text-black border border-gray-200 rounded py-3 px-4 mt-2" id="refreshButton" title="Refresh" style="width: 14%;border-right-width: 0;border-radius: 0; cursor: pointer">
                                &#x21BB;
                            </span>
                            <input class=" text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4 mt-2" id="company" value="{{old('trackable_hashtag')}}" placeholder=" Trackable Hashtag" type="text" name="trackable_hashtag" readonly style="border-left-width:0">
                            @error('trackable_hashtag')
                            <span class="text-red-600">{{ $message }}</span>
                            @enderror
                        </div>
                    </div>
                    <div class="md:w-1/2 px-3 mb-2 md:mb-0">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Required Hashtag
                            </label>
                            <div data-tooltip-target="tt-9" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-9" role="tooltip" class="absolute w-52 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Any hashtags you would like the influencer to use for this campaign.
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <input class=" text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4 mt-2" id="company" placeholder="Required Hashtag" value="{{old('required_hashtags')}}" type="text" name="required_hashtags">
                        @error('required_hashtags')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                </div>
                <div class="-mx-3 md:flex mb-2">
                    <div class="md:w-1/2 px-3">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Profile Tag
                            </label>
                            <div data-tooltip-target="tt-10" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-10" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Any instagram profiles you would like the influencer to tag when posting and sharing
                                their content.
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <input class=" text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4 mt-2" id="company" value="{{old('profile_tags')}}" placeholder=" Profile Tag" type="text" name="profile_tags" oninput="validateInput(this)">
                        @error('profile_tags')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="md:w-1/2 px-3">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Codes & Other info
                            </label>
                            <div data-tooltip-target="tt-11" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-11" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Option to provide a campaign promotion code that can be used when content is shared
                                and used to track to customers. (<i>i.e. Delivery10: giving 10% for customers that
                                    order
                                    through your online store and are able to input a promo code</i>)
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <input class=" text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4  mt-2" id="company" value="{{old('codes_other_info')}}" placeholder="Codes & Other info" type="text" name="codes_other_info">
                        @error('codes_other_info')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>
                </div>
                <div class="-mx-3 md:flex mb-2">
                    <div class="md:w-1/2 px-3 mb-2 md:mb-0">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Focus of Content
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-12" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-12" role="tooltip" class="absolute w-72 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Description of what you would like the influencer to focus on when creating the
                                content for this campaign. <br> <br>
                                <strong>
                                    Example
                                </strong> <br> (<i>The focus of the content for this campaign should be on showcasing our new menu items in a creative and engaging way. We encourage you to use your unique style and voice to highlight the flavors and presentation of our dishes, while also incorporating them into your dining experiences. We would like to see a mix of food close-ups, selfies with our food, and lifestyle shots that demonstrate the quality and taste of our cuisine. Please ensure that all content is in line with our brand values and messaging.</i>)
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <textarea class=" text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4 mt-2" id="focus_of_content" placeholder="Focus of Content" type="text" name="focus_of_content">{{old('focus_of_content')}}</textarea>
                        <p>Character length <span id="focusCharCount">0</span></p>
                        <strong id="focusErrorMessage" style="color: red; display: none;">Character limit exceeded!</strong>
                        <strong style="color: red; font-size: 12px; margin-top: -15px;" id="focusOfContentError"></strong>
                        @error('focus_of_content')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror

                    </div>
                    <div class="md:w-1/2 px-3 mb-2 md:mb-0">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Requirements
                            </label>
                            <p class="text-red-500 ml-1">*</p>
                            <div data-tooltip-target="tt-13" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-13" role="tooltip" class="absolute w-72 z-10 invisible inline-block p-8 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Outline what is required for the influencer to do when creating content as well as
                                any contact information that is required to completing the campaign. <br> <br>
                                <strong>
                                    Example
                                </strong>
                                <ul style="list-style: unset">
                                    <li>Create and publish a minimum of 3 sponsored posts featuring our products on
                                        your Instagram feed over the course of the campaign.
                                    </li>
                                    <li>Include at least one Instagram story highlight showcasing our products and
                                        linking to our website.
                                    </li>
                                    <li>Use the designated campaign hashtags and tag our brand in all sponsored
                                        posts.
                                    </li>
                                    <li>Adhere to all FTC guidelines regarding disclosure of sponsored content.</li>
                                </ul>
                                <br />
                                Provide us with a report at the end of the campaign detailing engagement
                                metrics such as likes, comments, and clicks.
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <textarea class=" text-xs w-full bg-white text-black border border-gray-200 rounded py-3 px-4  mt-2" placeholder="Requirements" id="requirement" type="text" name="requirement">{{old('requirement')}}</textarea>
                        <p>Character length <span id="reqCharCount">0</span></p>
                        <strong id="reqErrorMessage" style="color: red; display: none;">Character limit exceeded!</strong>
                        <strong style="color: red; font-size: 12px; margin-top: -15px;" id="requirementError"></strong>
                        @error('requirement')
                        <span class="text-red-600">{{ $message }}</span>
                        @enderror
                    </div>

                </div>
                <div class="-mx-3 md:flex mb-2">
                    <div class="md:w-1/2 px-3 mb-2 md:mb-0 mt-8">
                        <label class="inline-flex items-center">
                            <input type="checkbox" id="agreement" class="form-checkbox" required>
                            <a href="/influencer-agreement" target="_blank" class="flex">
                                <p class="ml-2" style="text-decoration: underline;">
                                    Posted Content Guidelines And Terms</p>
                                <p class="text-red-500 ml-1">*</p>
                            </a>
                        </label>
                        <strong style="color: red; font-size: 12px; margin-top: -15px;" id="agreementError"></strong>
                    </div>
                    <div class="md:w-1/2 px-3">

                        <div>
                            <div class="flex items-center">
                                <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                    Similar Content
                                </label>
                                <span class=" tracking-wide text-xs  font-sans flex">&nbsp;(Maximum of 4)</span>
                                <p class="text-red-500 ml-1">*</p>
                                <div data-tooltip-target="tt-14" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                    ?
                                </div>
                                <div id="tt-14" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                    Images and or videos that the influencer can take inspiration from when creating content for your brand.
                                    <div class="tooltip-arrow" data-popper-arrow></div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="drag-drop-area" class="flex flex-col items-center justify-center h-32 border-2 border-dashed border-gray-400 rounded-lg mt-2">
                            <span class="text-gray-500">Drag and drop your image here</span>
                            <label for="file-input" class="mt-2 cursor-pointer text-blue-500 py-2 px-4 rounded-lg">Browse</label>
                            <input type="file" id="file-input" name="similiar_image[]" multiple style="display: none;">

                        </div>
                        
<div id="image-container" class="flex mt-2"></div>

                    </div>


                </div>

                <div class=" flex w-full px-3 justify-center iteams-center py-10">
                    <button type="button" class="text-white self-center w-96 bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" onclick="backStep(2)">Previous
                    </button>
                    <button type="button" class="text-white self-center w-96 bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" onclick="showStep(3)">Next
                    </button>

                </div>
            </div>

        </div>

        <!-- Step 3 -->
        <div id="step-3" class="hidden bg-white mx-auto  py-4 px-4 lg:px-12 shadow-xl mb-24 rounded-3xl">
            <h2 class="text-center text-2xl font-semibold my-5">Target Influencers</h2>

            <div class="-mx-3 md:flex mb-10">
                <div class="md:w-1/2 px-3 mb-2 md:mb-0">
                    <div class="flex justify-between">
                        <div class="flex items-center">
                            <label class=" tracking-wide text-xs  font-sans flex" for="company">
                                Type of Content
                            </label>
                            <x-grey-label-text>
                                &nbsp;(Select all that apply)
                            </x-grey-label-text>
                            <p class="text-red-500 ml-1">*</p>


                            <div data-tooltip-target="tt-15" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                                ?
                            </div>
                            <div id="tt-15" role="tooltip" class="absolute w-[350px] z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                                Different types of posts/content the influencers are able to create for your
                                campaign.
                                Different types of content posts may vary in reach and engagement. Please refer to
                                pricing chart when selecting the type of content you would like the influencers to
                                create. <br>
                                <strong> Static Post-</strong> A singular image posted on the influencers Instagram
                                page. <br>
                                <strong> Carousel Post-</strong> A series of images posted on the influencers
                                Instagram
                                page, with a
                                scrolling(carousel) type format, up to 10. <br>
                                <strong> Static Story-</strong> A singular picture posted on the influencers story
                                through their page. Disappears after 24 hours of being posted. <br>
                                <strong> Video Story-</strong> A singular 15 second story. This being in video
                                format,
                                disappears after 24 hours of being posted. <br>
                                <strong> Reels-</strong> 60 second video clip that is published on the influencers
                                page
                                that is highly shareable and easily accessible. <br>
                                <strong> Instagram Video- </strong> Video that is uploaded on the influencers
                                Instagram
                                page. This video can vary from 3 seconds to 60 minutes. <br>
                                <div class="tooltip-arrow" data-popper-arrow></div>
                            </div>
                        </div>
                        <div><span data-modal-target="type-content-modal" data-modal-toggle="type-content-modal" class="text-gray-500 cursor-pointer border font-normal border-gray-500 rounded-full text-xs px-2 ml-1">!</span>
                        </div>
                    </div>
                    <select id="typeofcontent" multiple="multiple" name="type_of_content[]" required class="select2 typeofcontent text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                        @foreach ($type_content as $content => $id)
                        @if(old('type_of_content'))
                        <option value="{{$id->id}}" {{ in_array($id->id, old('type_of_content')) ? 'selected' : '' }}>{{$id->name}}</option>
                        @else
                        <option value="{{$id->id}}">{{$id->name}}</option>
                        @endif
                        @endforeach
                    </select>
                    @error('type_of_content')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
                <div class="md:w-1/2 px-3">
                    <div class="flex items-center">
                        <label class=" tracking-wide text-xs  font-sans flex" for="company">
                            Influencer Interest
                        </label>
                        <x-grey-label-text>
                            &nbsp;(Select all that apply)
                        </x-grey-label-text>
                        <p class="text-red-500 ml-1">*</p>
                        <div data-tooltip-target="tt-16" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                            ?
                        </div>
                        <div id="tt-16" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                            Category/Industry that the influencer specializes in.
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                    <select id="influencerinter" multiple="multiple" name="influencer_interest[]" required class="select2 text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                        @foreach ($influencer_interest as $interest => $id)
                        @if(old('influencer_interest'))
                        <option value="{{$id->id}}" {{ in_array($id->id, old('influencer_interest')) ? 'selected' : '' }}>{{$id->name}}</option>
                        @else
                        <option value="{{$id->id}}">{{$id->name}}</option>
                        @endif
                        @endforeach
                    </select>
                    @error('influencer_interest')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
            </div>
            <div class="-mx-3 md:flex mb-10">
                <div class="md:w-1/2 px-3">
                    <div class="flex items-center">
                        <label class=" tracking-wide text-xs  font-sans flex" for="company">
                            Influencer Location
                        </label>
                        <p class="text-red-500 ml-1">*</p>
                        <div data-tooltip-target="tt-17" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                            ?
                        </div>
                        <div id="tt-17" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                            Influencer geographic location.
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                    <select name="influencer_location" id="locationInfluencer" required class="select3 cities text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                        <option value="">Select Location</option>
                        @foreach ($locations as $location)
                        <option value="{{$location->id}}" {{old('influencer_location') == $location->id ? 'selected' : '' }}>{{$location->name}}</option>
                        @endforeach
                    </select>
                    @error('influencer_location')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
                <div class="md:w-1/2 px-3">
                    <div class="flex items-center">
                        <label class=" tracking-wide text-xs  font-sans flex" for="company">
                            Influencer City
                        </label>
                        <p class="text-red-500 ml-1">*</p>
                        <div data-tooltip-target="tt-17" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                            ?
                        </div>
                        <div id="tt-17" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                            Influencer geographic city.
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                    <select name="influencer_city" id="influencerCities" class="select3 text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                    </select>
                    @error('influencer_city')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
            </div>

            <hr>
            <h2 class="text-center text-2xl font-semibold my-5 py-8">Target Audience</h2>
            <div class="-mx-3 md:flex mb-2">
                <div class="md:w-1/2 px-3 mb-3 md:mb-0">
                    <div class="flex items-center">
                        <label class=" tracking-wide text-xs  font-sans flex" for="company">
                            Audience Location
                        </label>
                        <p class="text-red-500 ml-1">*</p>
                        <div data-tooltip-target="tt-18" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                            ?
                        </div>
                        <div id="tt-18" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                            Location of your target audience.
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                    <select name="audience_location" class="select4 audienceCities text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                        <option value="">Select Location</option>
                        @foreach ($locations as $location)
                        <option value="{{$location->id}}" {{old('audience_location') == $location->id ? 'selected' : '' }}>{{$location->name}}</option>
                        @endforeach
                    </select>
                    @error('audience_location')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
                <div class="md:w-1/2 px-3 mb-3 md:mb-0">
                    <div class="flex items-center">
                        <label class="tracking-wide text-xs  font-sans flex" for="company">
                            Audience City
                        </label>
                        <p class="text-red-500 ml-1">*</p>
                        <div data-tooltip-target="tt-18" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                            ?
                        </div>
                        <div id="tt-18" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                            City of your target audience.
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                    <select name="audience_city" id="audienceCities" required class="select4 text-xs cityAudience w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3">
                    </select>
                    @error('audience_city')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
            </div>
            <div class="-mx-3 md:flex mb-2">
                <div class="md:w-1/2 px-3">
                    <div class="flex items-center">
                        <label class=" tracking-wide text-xs  font-sans flex" for="company">
                            Audience Age
                        </label>
                        <x-grey-label-text>
                            &nbsp;(Select all that apply)
                        </x-grey-label-text>
                        <p class="text-red-500 ml-1">*</p>
                        <div data-tooltip-target="tt-19" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                            ?
                        </div>
                        <div id="tt-19" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                            Age of your target audience.
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                    <select name="audience_age[]" required multiple="multiple" class="select5 text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded
                                 py-3 px-4 mb-3" id="audience_age">
                        <?php $ageGroup = ['18-24', '25-34', '35-44', '45-54', '55-64', '65+'] ?>
                        @foreach ($ageGroup as $age)
                        @if(old('audience_age'))
                        <option value="{{$age}}" {{ in_array($age, old('audience_age')) ? 'selected' : '' }}>{{$age}}</option>
                        @else
                        <option value="{{$age}}">{{$age}}</option>
                        @endif
                        @endforeach
                    </select>
                    @error('audience_age')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
                <div class="md:w-1/2 px-3">
                    <div class="flex items-center">
                        <label class=" tracking-wide text-xs  font-sans flex" for="company">
                            Audience Languages
                        </label>
                        <p class="text-red-500 ml-1">*</p>
                        <div data-tooltip-target="tt-20" data-tooltip-style="light" class="w-[14px] h-[14px] text-xs text-white ml-2 bg-gray-300 rounded-full text-center cursor-pointer">
                            ?
                        </div>
                        <div id="tt-20" role="tooltip" class="absolute w-48 z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg shadow-sm opacity-0 tooltip">
                            Primary language of your target audience.
                            <div class="tooltip-arrow" data-popper-arrow></div>
                        </div>
                    </div>
                    <select name="audience_language" required class=" text-xs w-full bg-white text-black mt-2 border border-gray-200 rounded py-3 px-4 mb-3" id="audience_language" type="text">
                        <option value="" disabled>Select a language</option>
                        <option value="English" selected>English</option>
                    </select>
                    @error('audience_language')
                    <span class="text-red-600">{{ $message }}</span>
                    @enderror
                </div>
            </div>
            <div class=" flex w-full px-3 py-10 justify-center items-center">
                <button type="button" class="text-white self-center w-96 bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700" onclick="backStep(3)">Previous
                </button>
                <button type="submit" class="text-white self-center w-96 bg-gray-800 hover:bg-gray-900 focus:outline-none focus:ring-4 focus:ring-gray-300 font-medium rounded-full text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-gray-800 dark:hover:bg-gray-700 dark:focus:ring-gray-700 dark:border-gray-700">
                    Done
                </button>
            </div>
        </div>
    </form>
    <!-- Type of Content Modal -->
    <div id="type-content-modal" tabindex="-1" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative w-full max-w-max max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-5 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-xl font-medium text-gray-900 dark:text-white">
                        Payout List
                    </h3>
                    <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="type-content-modal">
                        <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <div class="overflow-x-auto shadow-lg rounded-lg bg-white">
                    <table class=" w-full">
                        <thead class="bg-gray-100">
                            <tr>
                                <th scope="col" class="px-6 py-2 font-medium">Static Post</th>
                                <th scope="col" class="px-6 py-2 font-medium">Carousel Post</th>
                                <th scope="col" class="px-6 py-2 font-medium">Static Story</th>
                                <th scope="col" class="px-6 py-2 font-medium">Video Story</th>
                                <th scope="col" class="px-6 py-2 font-medium">Reels</th>
                                <th scope="col" class="px-6 py-2 font-medium">Instagram Video</th>
                                <th scope="col" class="px-6 py-2 font-medium">Followers</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($payouts as $trans)
                            <tr class="border-b py-4">
                                <td class="text-center font-medium">$ {{$trans->static_post}}</td>
                                <td class="text-center font-medium">$ {{$trans->carousel_post}}</td>
                                <td class="text-center font-medium">$ {{$trans->static_story}}</td>
                                <td class="text-center font-medium">$ {{$trans->video_story}}</td>
                                <td class="text-center font-medium">$ {{$trans->reels}}</td>
                                <td class="text-center font-medium">$ {{$trans->instagram_video}}</td>
                                <td class="text-center font-medium">{{$trans->follower_min}}
                                    - {{$trans->follower_max}}</td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="6">
                                    @include('components.no-data')
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="{{asset('js/ckeditor/ckeditor.js')}}"></script>
<script>
const dragDropArea = document.getElementById('drag-drop-area');
const imageContainer = document.getElementById('image-container');
const fileInput = document.getElementById('file-input');

let imageCount = 0;
let selectedImages = [];

dragDropArea.addEventListener('dragover', (e) => {
  e.preventDefault();
  dragDropArea.classList.add('border-blue-500');
});

dragDropArea.addEventListener('dragleave', () => {
  dragDropArea.classList.remove('border-blue-500');
});

dragDropArea.addEventListener('drop', (e) => {
  e.preventDefault();
  dragDropArea.classList.remove('border-blue-500');
  const files = e.dataTransfer.files;
  handleFiles(files);
});

fileInput.addEventListener('change', (e) => {
  const files = e.target.files;
  handleFiles(files);
});

function handleFiles(files) {
  for (let i = 0; i < files.length; i++) {
    if (imageCount >= 4) {
      console.log('Only four images are allowed.');
      return;
    }
    const file = files[i];
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = document.createElement('img');
      img.src = e.target.result;
      img.classList.add('w-24', 'h-24', 'object-cover', 'rounded');
      imageContainer.appendChild(img);
      imageCount++;

      // Add the image data to the selectedImages array
      selectedImages.push(file);

      // Update the value of the input field
      fileInput.value = selectedImages.join();
    };
    reader.readAsDataURL(file);
  }
}




    function loadImage(input, img) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $(img).attr('src', e.target.result);
                    $(img).removeClass('hidden');
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

    $(document).ready(function() { 
        $('.campaignImg').change(function () {
                loadImage(this, "#campaignImg img");
            });

        $('#typeofcontent').on('change', function() {
            var selectedOptions = $(this).val();

            if (selectedOptions && selectedOptions.includes('2') && !selectedOptions.includes('1')) {
                // Show validation error message or perform desired action
                toastr.error("Static Post Required: A carousel campaign must include static post.");
                // alert('Static Post Required: A carousel campaign must include static post.');
            } else {
                // No validation error, continue with your logic
                console.log('Valid selection');
            }
        });

        $('.cities').change(function() {
            var countryId = $(this).val();
            $.ajax({
                url: "{{url('get-cities')}}",
                method: 'get',
                data: {
                    countryId,
                },
                success: function(result) {
                    var citiesHtml = result;
                    var sortedCities = $(citiesHtml).sort(function(a, b) {
                        var textA = $(a).text().toUpperCase();
                        var textB = $(b).text().toUpperCase();
                        return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                    });
                    var sortedHtml = $.map(sortedCities, function(option) {
                        return option.outerHTML;
                    }).join('\n');

                    var selectCityOption = '<option value="">Select City</option>';
                    sortedHtml = selectCityOption + sortedHtml;

                    $('#influencerCities').empty().append(sortedHtml);
                },
                error: function(e) {
                    console.error(e);
                }
            })
        }).trigger('change');

        $('.audienceCities').change(function() {
            var countryId = $(this).val();
            $.ajax({
                url: "{{url('get-cities')}}",
                method: 'get',
                data: {
                    countryId,
                },
                success: function(result) {
                    var citiesHtml = result;
                    var sortedCities = $(citiesHtml).sort(function(a, b) {
                        var textA = $(a).text().toUpperCase();
                        var textB = $(b).text().toUpperCase();
                        return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                    });
                    var sortedHtml = $.map(sortedCities, function(option) {
                        return option.outerHTML;
                    }).join('\n');
                    var selectCityOption = '<option value="">Select City</option>';
                    sortedHtml = selectCityOption + sortedHtml;
                    $('#audienceCities').empty().append(sortedHtml);
                },
                error: function(e) {
                    console.error(e);
                }
            })
        }).trigger('change');

        $('.select2').select2();
        $('.select3').select2();
        $('.select4').select2();
        $('.select5').select2();
        $('#hide-campaign').click(function() {
            $('#campaign-modal').addClass('hidden');
        })


        let ckeditorOptions = {
            height: 160,
            toolbar: [{
                    name: 'basicstyles',
                    groups: ['basicstyles'],
                    items: ['Bold', 'Italic']
                },
                {
                    name: 'paragraph',
                    groups: ['list', 'indent', 'blocks', 'align', 'bidi'],
                    items: ['NumberedList', 'BulletedList']
                },
            ]
        };

        var editor =  CKEDITOR.replace('summernote_summary', ckeditorOptions);
        var focusEditor = CKEDITOR.replace('focus_of_content', ckeditorOptions);
        var reqEditor = CKEDITOR.replace('requirement', ckeditorOptions);

        var charCountElement = $('#summeryCharCount');
        var errorMessageElement = $('#summeryErrorMessage');

        var charCountElement = $('#focusCharCount');
        var errorMessageElement = $('#focusErrorMessage');

        var charCountElement = $('#reqCharCount');
        var errorMessageElement = $('#reqErrorMessage');

        var charLimit = 2000;

        function updateCharCount() {
            var content = editor.getData();
            var charCount = content.length;
            charCountElement.text(charCount);

            if (charCount > charLimit) {
            errorMessageElement.show();
            } else {
            errorMessageElement.hide();
            }
        }

        editor.on('key', updateCharCount);
        editor.on('paste', updateCharCount);
        editor.on('setData', updateCharCount);
        focusEditor.on('key', updateCharCount);
        focusEditor.on('paste', updateCharCount);
        focusEditor.on('setData', updateCharCount);
        reqEditor.on('key', updateCharCount);
        reqEditor.on('paste', updateCharCount);
        reqEditor.on('setData', updateCharCount);
        updateCharCount();
    });

    let currentStep = 1;

    function showStep(stepNumber) {
        if (stepNumber === 1) {
            document.getElementById("step-1").classList.remove("hidden");
            document.getElementById("step-2").classList.add("hidden");
            document.getElementById("step-3").classList.add("hidden");
            currentStep = 1;
        } else if (stepNumber === 2) {
            if (CKEDITOR.instances.summernote_summary.getData() == '') {
                $('#summaryError').html('Campaign Summary is required');
                return;
            }
            if (validateFields("step-1") === false) return;

            document.getElementById("step-1").classList.add("hidden");
            document.getElementById("step-2").classList.remove("hidden");
            document.getElementById("step-3").classList.add("hidden");
            currentStep = 2;
        } else {
            if (CKEDITOR.instances.focus_of_content.getData() == '') {
                $('#focusOfContentError').html('Focus of Content is required');
                return;
            } else if (CKEDITOR.instances.requirement.getData() == '') {
                $('#requirementError').html('Requirements is required');
                return;
            } else if (!$('#agreement').is(':checked')) {
                $('#agreementError').html('Agreement is required');
                return;
            }
            if (validateFields("step-2") === false) return;
            document.getElementById("step-1").classList.add("hidden");
            document.getElementById("step-2").classList.add("hidden");
            document.getElementById("step-3").classList.remove("hidden");
            currentStep = 3;
        }
    }

    function backStep(stepNumber) {
        if (stepNumber === 2) {
            document.getElementById("step-1").classList.remove("hidden");
            document.getElementById("step-2").classList.add("hidden");
            document.getElementById("step-3").classList.add("hidden");
            currentStep = 2;
        } else {
            document.getElementById("step-1").classList.add("hidden");
            document.getElementById("step-2").classList.remove("hidden");
            document.getElementById("step-3").classList.add("hidden");
            currentStep = 3;
        }
    }

    function validateFields(id) {
        const stepOne = document.getElementById(id);
        const inputs = stepOne.querySelectorAll('input,select');

        const inputField1 = document.querySelector('input[name="required_hashtags"]');
        const inputField2 = document.querySelector('input[name="profile_tags"]');
        const inputField3 = document.querySelector('input[name="codes_other_info"]');
        const inputfile = document.querySelector('input[id="similiar_image"]');

        let hasEmptyField = false;

        for (let index = 0; index < inputs.length; index++) {
            let value = inputs[index].value.trim();
            let parentDiv = inputs[index].parentNode;
            if (value === '' && inputs[index] !== inputField1 && inputs[index] !== inputField2 && inputs[index] !== inputField3 || inputs[index] == inputfile && inputfile.value == '') {
                hasEmptyField = true;
                let labelElement = parentDiv.querySelector('label');
                let label = labelElement ? labelElement.textContent.trim() : 'Add Campaign Picture';
                if (!parentDiv.querySelector('strong')) { // check if error message element already exists
                    let error = document.createElement('strong');
                    error.textContent = label + ' is required';
                    error.style.color = 'red';
                    error.style.fontSize = '12px';
                    error.style.marginTop = '-15px';

                    parentDiv.appendChild(error);
                }
            } else {
                let error = parentDiv.querySelector('strong');
                if (error) {
                    // parentDiv.removeChild(error);
                }
            }
        }

        return !hasEmptyField; // return true if no empty input fields are found
    }

    function calculateBudget(input) {
        var value = input.value;
        var budgetResult = input.parentNode.querySelector('.budget-result');

        if (value !== '') {
            var budget = parseInt(value) * 20;
            budgetResult.textContent = 'Potential Reach: ' + budget + ' people';
            budgetResult.style.fontSize = '12px';
        } else {
            budgetResult.textContent = '';
        }
    }


    $(document).ready(function() {
        $('#mySelect').select2({
            placeholder: 'Select Campaign Objective',
            closeOnSelect: false,
            allowClear: true,
            tags: true
        });

        $('.cityAudience').select2({
            placeholder: 'Select Audience City',
            closeOnSelect: false,
            allowClear: true,
            tags: true
        });

        $('#typeofcontent').select2({
            placeholder: 'Select Type of Content',
            closeOnSelect: false,
            allowClear: true,
            tags: true
        });

        $('#influencerinter').select2({
            placeholder: 'Select Influencer Interest',
            closeOnSelect: false,
            allowClear: true,
            tags: true
        });

        $('#audience_age').select2({
            placeholder: 'Select age of your target audience',
            closeOnSelect: false,
            allowClear: true,
            tags: true
        });
    });
    // refresh button

    const input = document.querySelector('input[name="trackable_hashtag"]');;
    const refreshButton = document.querySelector('#refreshButton');


    refreshButton.addEventListener('click', function() {
        generateRandomHashtag();
    });

    function generateRandomHashtag() {
        fetch('/generate-random-hashtag')
            .then(response => response.json())
            .then(data => {
                input.value = data.random_hashtag;
            })
            .catch(error => {
                console.log('Error:', error);
            });
    }

    const fresh = document.querySelector('#fresh');

    fresh.addEventListener('click', function() {
        generateRandomHashtag();
    });


    function handlecampaignbudget() {
        var productSelect = document.getElementById("campaign_type");
        var campaign_budgetInput = document.getElementById("campaign_budget");
        if (productSelect.value === "gift") {
            campaign_budgetInput.value = "0";
            campaign_budgetInput.setAttribute("readonly", true);
        } else {
            campaign_budgetInput.value = "";
            campaign_budgetInput.removeAttribute("readonly");
        }
    }


    function validateInput(input) {
        var regex = /^[a-zA-Z0-9]+$/;
        var inputValue = input.value;

        if (!regex.test(inputValue)) {
            input.value = inputValue.replace(/[^a-zA-Z0-9]/g, '');
        }
    }
</script>
@endpush
@endsection
@push('style')
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    #similiar_div_1 img {
        border-radius: 15%;
        height: 80px;
        width: 80px;
        object-fit: cover;
        cursor: pointer;
    }

    #similiar_div_2 img {
        border-radius: 15%;
        height: 80px;
        width: 80px;
        object-fit: cover;
        cursor: pointer;
    }

    #similiar_div_3 img {
        border-radius: 15%;
        height: 80px;
        width: 80px;
        object-fit: cover;
        cursor: pointer;
    }

    #similiar_div_4 img {
        border-radius: 15%;
        height: 80px;
        width: 80px;
        object-fit: cover;
        cursor: pointer;
    }

    .select2-container .select2-search--inline .select2-search__field {
        font-size: 0.75rem !important;
    }

    .select2-container--default .select2-results__option--highlighted.select2-results__option--selectable {
        background-color: #ddd;
        color: black;
    }
</style>
@endpush